import React from 'react';

const NotFound = () => {
  return <div>
    <h2 style={{ marginBottom: 0 }}>404</h2>
    <h4 style={{ marginTop: 0 }}>Page Not Found!</h4>
  </div>
}

export default NotFound;