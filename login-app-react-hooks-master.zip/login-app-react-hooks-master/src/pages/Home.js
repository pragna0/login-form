import React from 'react';

const Home = () => {
  return <div>
    Welcome to the Home Page!
  </div>
}

export default Home;